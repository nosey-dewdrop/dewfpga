`timescale 1ns/1ps

module blink_tb;
    logic        clk = 0;
    logic [15:0] sw = '0;
    logic [15:0] led;


     blink dut (.clk(clk), .sw(sw), .led(led));

     always #5 clk = ~clk;

     initial begin
           $dumpfile("blink.vcd");
           $dumpvars(0, blink_tb);

           sw[0] = 0; #100;
           if (led[15] !== 1'b0) $error("sw[0]=0 should give led[15]=0");


           sw[0] = 1; #100;
           if (led[15] !== 1'b1) $error("sw[0]=1 should give led[15]=1");

           $display("TB passed");
           $finish;
    end
endmodule

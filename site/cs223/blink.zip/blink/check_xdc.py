#!/usr/bin/env python3
import json, re, sys

jf, xf = sys.argv[1], sys.argv[2]

design = json.load(open(jf))
top = None
for name, mod in design["modules"].items():
    if mod.get("attributes", {}).get("top"):
        top = (name, mod); break
if top is None:
    name = list(design["modules"])[0]
    top = (name, design["modules"][name])
tname, tmod = top

ports = set()
for pn, info in tmod.get("ports", {}).items():
    n = len(info.get("bits", []))
    if n == 1:
        ports.add(pn)
    else:
        ports.update(f"{pn}[{i}]" for i in range(n))

xdc = set()
for line in open(xf):
    line = line.split("#")[0]
    for m in re.finditer(
            r"get_ports\s*\{?\s*([A-Za-z_]\w*(?:\[\d+\])?)", line):
        xdc.add(m.group(1))


missing = sorted(ports - xdc)
extra   = sorted(xdc - ports)

if missing:
    print(f"No pin assignment in the xdc for ({tname}):")
    for x in missing: print(f"   - {x}")
if extra:
    print("In the xdc but not in the design, probably a typo:")
    for x in extra: print(f"   - {x}")

if missing or extra:
    sys.exit(1)
print(f"xdc ok: {len(ports)} ports, all matched.")

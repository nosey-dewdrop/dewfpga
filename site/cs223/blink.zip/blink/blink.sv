module blink (
    input logic             clk,
     input logic [15:0] sw,
     output logic [15:0] led
);
     localparam int HALF_PERIOD = 50_000_000;

     logic [25:0] counter = '0;
     logic           blink_state = 1'b0;

     always_ff @(posedge clk) begin
         if (counter == HALF_PERIOD - 1) begin
             counter     <= '0;
             blink_state <= ~blink_state;
           end else begin
               counter <= counter + 1'b1;
           end
     end

     always_comb begin
           led     = '0;
           led[0] = blink_state & sw[0];
           led[15] = sw[0];
    end
endmodule
